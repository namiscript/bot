require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const DISCORD_API = 'https://discord.com/api/v9';
const GHOST = 'https://ghosthub.fun';
const sessions = new Map();

function dHeaders(token) {
  return {
    'Authorization': token,
    'Content-Type': 'application/json',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
  };
}

function ghHeaders(token) {
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'x-site-token': token } : {}),
    'Origin': GHOST,
    'Referer': GHOST + '/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
  };
}

async function connectGhosthub(token) {
  try {
    const r = await axios.post(`${GHOST}/api/connect`, { token }, {
      headers: ghHeaders(), timeout: 20000
    });
    if (!r.data?.siteToken) return { error: 'ghosthub nao retornou token' };
    return { success: true, siteToken: r.data.siteToken };
  } catch (e) {
    const msg = e.response?.data?.error || e.message;
    console.error('[GHOST] connect error:', msg);
    return { error: msg };
  }
}

// ==============================
// CONNECT
// ==============================
app.post('/api/connect', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token || token.length < 50) {
      return res.status(400).json({ success: false, error: 'Token invalido' });
    }

    const userRes = await axios.get(`${DISCORD_API}/users/@me`, {
      headers: dHeaders(token), timeout: 15000
    });
    const user = userRes.data;

    const sid = uuidv4();
    const ghRes = await connectGhosthub(token);
    const ghToken = ghRes?.success ? ghRes.siteToken : null;
    sessions.set(sid, { discordToken: token, ghToken, user, createdAt: Date.now() });
    if (!ghToken) console.error('[GHOST] connect failed for user ' + user.username + ':', ghRes?.error);
    setTimeout(() => sessions.delete(sid), 30 * 60 * 1000);

    const avatar = user.avatar
      ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=256`
      : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(user.id) >> 22n) % 6}.png`;

    res.json({ success: true, siteToken: sid, username: user.username, id: user.id, avatar });
  } catch (e) {
    if (e.response?.status === 401) {
      return res.status(401).json({ success: false, error: 'Token invalido ou expirado' });
    }
    res.status(500).json({ success: false, error: 'Erro ao conectar' });
  }
});

// ==============================
// PERFIL
// ==============================
app.get('/api/profile', async (req, res) => {
  try {
    const sid = req.headers['x-site-token'];
    if (!sid || !sessions.has(sid)) {
      return res.status(401).json({ error: 'Sessao expirada', expired: true });
    }
    const session = sessions.get(sid);
    const u = await axios.get(`${DISCORD_API}/users/@me`, {
      headers: dHeaders(session.discordToken), timeout: 15000
    }).then(r => r.data);

    const avatar = u.avatar
      ? `https://cdn.discordapp.com/avatars/${u.id}/${u.avatar}.${u.avatar.startsWith('a_') ? 'gif' : 'png'}?size=256`
      : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(u.id) >> 22n) % 6}.png`;

    res.json({
      id: u.id, username: u.username, discriminator: u.discriminator,
      global_name: u.global_name, avatar, premium_type: u.premium_type,
      flags: u.flags, banner: u.banner
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ==============================
// QUESTS — fallback (browser tenta direto primeiro)
// ==============================
app.get('/api/quests', async (req, res) => {
  try {
    const sid = req.headers['x-site-token'];
    if (!sid || !sessions.has(sid)) {
      return res.status(401).json({ error: 'Sessao expirada', expired: true });
    }
    const session = sessions.get(sid);
    let quests = [];

    if (session.ghToken) {
      try {
        const gh = await axios.get(`${GHOST}/api/quests`, {
          headers: ghHeaders(session.ghToken), timeout: 20000
        });
        quests = gh.data?.quests || [];
        return res.json({ quests });
      } catch (e) { console.error('[GHOST] quests with existing token failed:', e.message); session.ghToken = null; }
    }

    const ghRes = await connectGhosthub(session.discordToken);
    if (ghRes?.success) {
      session.ghToken = ghRes.siteToken;
      try {
        const gh = await axios.get(`${GHOST}/api/quests`, {
          headers: ghHeaders(ghRes.siteToken), timeout: 20000
        });
        quests = gh.data?.quests || [];
      } catch (e) { console.error('[GHOST] quests with new token failed:', e.message); }
    } else {
      console.error('[GHOST] quests reconnect failed:', ghRes?.error);
    }

    res.json({ quests });
  } catch (e) {
    res.status(500).json({ error: 'Erro ao buscar missoes' });
  }
});

// ==============================
// COMPLETAR — fallback
// ==============================
app.post('/api/quests/:id/complete', async (req, res) => {
  try {
    const sid = req.headers['x-site-token'];
    if (!sid || !sessions.has(sid)) {
      return res.status(401).json({ error: 'Sessao expirada', expired: true });
    }
    const session = sessions.get(sid);
    const questId = req.params.id;

    if (!session.ghToken) {
      const ghRes = await connectGhosthub(session.discordToken);
      if (ghRes?.success) {
        session.ghToken = ghRes.siteToken;
      } else {
        console.error('[GHOST] complete reconnect failed:', ghRes?.error);
        return res.status(500).json({ success: false, error: 'Ghosthub: ' + (ghRes?.error || 'indisponivel') });
      }
    }

    if (session.ghToken) {
      try {
        const gh = await axios.post(`${GHOST}/api/quests/${questId}/complete`, {}, {
          headers: ghHeaders(session.ghToken), timeout: 30000
        });
        return res.json(gh.data);
      } catch (e) {
        const msg = e.response?.data?.error || e.message;
        console.error('[GHOST] complete error:', msg, e.response?.status);
        session.ghToken = null;
        return res.status(500).json({ success: false, error: 'Ghosthub: ' + msg });
      }
    }
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ==============================
// STATUS — fallback
// ==============================
app.get('/api/quests/:id/status', async (req, res) => {
  try {
    const sid = req.headers['x-site-token'];
    if (!sid || !sessions.has(sid)) {
      return res.status(401).json({ error: 'Sessao expirada', expired: true });
    }
    const session = sessions.get(sid);

    if (!session.ghToken) {
      const ghRes = await connectGhosthub(session.discordToken);
      if (ghRes?.success) session.ghToken = ghRes.siteToken;
    }

    if (session.ghToken) {
      try {
        const gh = await axios.get(`${GHOST}/api/quests`, {
          headers: ghHeaders(session.ghToken), timeout: 20000
        });
        const quest = (gh.data?.quests || []).find(q => q.id === req.params.id);
        if (quest) {
          const st = quest.user_status;
          const progress = (() => {
            if (!st || !st.progress) return { current: 0, total: 0, pct: 0 };
            const t = Object.keys(st.progress)[0];
            const cur = st.progress[t]?.value || 0;
            const tasks = quest.config?.task_config_v2?.tasks || {};
            const tot = tasks[t]?.target || 0;
            return { current: cur, total: tot, pct: tot > 0 ? Math.min(100, Math.floor(cur / tot * 100)) : 0 };
          })();
          return res.json({
            id: quest.id,
            status: st?.claimed_at ? 'claimed' : st?.completed_at ? 'completed' : st?.enrolled_at ? 'enrolled' : 'available',
            progress,
            reward: st?.orb_quantity_claimed || 'Orbs'
          });
        }
      } catch (_) { session.ghToken = null; }
    }

    res.status(404).json({ error: 'Missao nao encontrada' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ==============================
// DIAGNOSTICO
// ==============================
app.get('/api/ghost-check', async (req, res) => {
  try {
    const r = await axios.get(`${GHOST}/`, { timeout: 10000 });
    res.json({ reachable: true, status: r.status });
  } catch (e) {
    res.json({ reachable: false, error: e.message, code: e.code });
  }
});

app.listen(PORT, () => {
  console.log(`Nocteris rodando em http://localhost:${PORT}`);
});
